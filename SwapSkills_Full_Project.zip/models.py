# Password hashing and DB functions
