EMAIL_ADDRESS = "sachinryadav1805@gmail.com"
EMAIL_PASSWORD = "sachinyadav1234"  # 16-character app password
