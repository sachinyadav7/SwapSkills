# Helper functions (if needed)
